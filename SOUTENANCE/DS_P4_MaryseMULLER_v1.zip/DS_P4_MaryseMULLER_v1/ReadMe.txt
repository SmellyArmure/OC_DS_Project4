Bonjour,
La présentation n'est pas tout à fait complète, quelques slides sont en cours de perfectionnement et seront ajoutés sous peu.
Désolée du retard.
Cordialement.
Maryse Muller.